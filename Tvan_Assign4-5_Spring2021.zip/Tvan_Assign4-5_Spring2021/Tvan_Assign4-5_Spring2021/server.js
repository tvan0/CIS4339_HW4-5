const MongoClient = require('mongodb').MongoClient;
const uri = "mongodb+srv://tvan:Tifuyen702164!@cluster0.fzspa.mongodb.net/BlogMembers?retryWrites=true&w=majority";
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
const dbName = "BlogMembers";

let express = require('express');
let app = express();

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));

app.get('/', (req, res) => {
    res.render('home', { foo: 'FOO' });
});

app.get('/logreg', (req, res) => {
    res.render('logreg', { foo: 'FOO' });
});

app.get('/post', (req, res) => {
    res.render('post', { foo: 'FOO' });
});

app.get('/blogs', (req, res) => {
    res.render('blogs', { foo: 'FOO' });
});

app.get('/search', (req, res) => {
    res.render('search', { foo: 'FOO' });
});

app.listen(4000, () => console.log('Example app listening on port 4000!'));

async function createDatabaseCollection() {
    console.log("called upon");
    try {
        await client.connect();
        console.log("Connected correctly to server");

        // create a constant variable called db from the client
        const db = client.db(dbName);

        // Use the collection "people", and if collection "people" does not exist, it will be created automatically
        const col = db.collection("people");

        // Construct a document, this is a example document to insert into the collection, this is in the form of key:value pairs or JSON                                                                                                                                                         
        let personDocument = {
            "name": { "first": "TVAN", "last": "TVAN" },
            "birth": new Date(1912, 5, 23), // June 23, 1912                                                                                                                                 
            "death": new Date(1954, 5, 7),  // June 7, 1954                                                                                                                                  
            "contribs": ["Turing machine", "Turing test", "Turingery"],
            "views": 1250000
        }
        // Insert a single document, wait for promise so we can read it back
        const p = await col.insertOne(personDocument);

        // Find one document
        const myDoc = await col.findOne();

        console.log(myDoc);

    } catch (err) {
        console.log(err.stack);
    }

    finally {
        await client.close();
    }
}